
// sourced from - https://stackoverflow.com/questions/2114797/compute-median-of-values-stored-in-vector-c/2114817#2114817
#include "headerFile.h"

int testMedian(vector<int> &input)
{
    vector<int> sortedVect(input);
    sort(sortedVect.begin(), sortedVect.end());

    size_t size = sortedVect.size();
    if(size == 0)
    {
        return 0;
    }else{
        sort(input.begin(), input.end());
        return size % 2 == 0 ? ceil((input[size / 2.0 - 1] + input[size / 2.0]) / 2.0) : input[size / 2];
    }
}